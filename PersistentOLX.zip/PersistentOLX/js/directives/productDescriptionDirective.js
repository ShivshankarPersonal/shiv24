angular.module('productDescription', [])
    .directive('productDescription', function () {
        return {
            restrict: 'A',
            templateUrl: 'templates/productDescriptionPartials.html',
            controller:'productDetailsController'
        }
    });