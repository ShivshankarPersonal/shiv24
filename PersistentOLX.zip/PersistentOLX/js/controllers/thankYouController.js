angular.module("persistentOLXApp")
    .controller("thankYouController", function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        if (!sessionStorage.getItem("loginId")) {
            $location.path("/login");
        }
        $rootScope.searchBox = false;
        $rootScope.cartCount = null;
        persistentOLXFactory.address = {};
        sessionStorage.removeItem('loginId');
    });