angular.module("persistentOLXApp")
    .controller("checkOutController", function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        $rootScope.searchBox = true;
        if (!sessionStorage.getItem("loginId")) {
            $location.path("/login");
        }
        $scope.onEmailFocus = false;
        $scope.wrongMobile = false;
        $scope.userName = false;
        $scope.addressFieldError = false;
        $scope.breadCrumbs = [{
            name:'Home',
            state:'login'
        }, {
            name:'Product Catalogue',
            state:'productCatalogue'
        }, {
            name:'Product Details',
            state:'productDetails'
        }, {
            name:'Cart Details',
            state:'cart'
        }, {
            name:'Check Out',
            state:'checkOut'
        }];
        $scope.onNameFieldFocus = function () {
            $scope.nameFieldError = true;
        };
        $scope.onEmailFieldFocus = function () {
            $scope.onEmailFocus = true;
        };
        $scope.onMobileFieldBlur = function () {
            if ($scope.mobile) {
                if ($scope.mobile.toString().length !== 10) {
                    $scope.wrongMobile = true;
                } else {
                    $scope.wrongMobile = false;
                }
            }
            else {
                $scope.wrongMobile = true
            }
        };
        $scope.onMobileFieldFocus = function () {
            $scope.wrongMobile = false;
        };
        $scope.onAddressFieldFocus = function () {
            $scope.addressFieldError = true;
        };
        $scope.name = persistentOLXFactory.address.name;
        $scope.email = persistentOLXFactory.address.email;
        $scope.mobile = persistentOLXFactory.address.mobile;
        $scope.address = persistentOLXFactory.address.address;
        $scope.onSubmit = function (validity) {
            persistentOLXFactory.address.name = $scope.name;
            persistentOLXFactory.address.email = $scope.email;
            persistentOLXFactory.address.mobile = $scope.mobile;
            persistentOLXFactory.address.address = $scope.address;
            if ($scope.formStatus) {
                $state.go('purchaseSummary');
            }
        }
    });