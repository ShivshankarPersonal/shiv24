angular.module('persistentOLXApp')
    .controller('sellerInformationController', function ($scope, persistentOLXFactory, $state, $location) {
        if (!sessionStorage.getItem("loginId")) {
            $location.path("/login");
        }
        var data = persistentOLXFactory.itemDetails;
        $scope.sellerInfo = data.sellerInfo;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });