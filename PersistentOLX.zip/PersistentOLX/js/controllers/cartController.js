angular.module("persistentOLXApp")
    .controller("cartController", function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        $rootScope.searchBox = true;
        if (!sessionStorage.getItem("loginId")) {
            $location.path("/login");
        }
        $scope.breadCrumbs = [{
            name: 'Home',
            state: 'login'
        }, {
            name: 'Product Catalogue',
            state: 'productCatalogue'
        }, {
            name: 'Product Details',
            state: 'productDetails'
        }, {
            name: 'Cart Details',
            state: 'cart'
        }];
        renderCartTable();
        function renderCartTable() {
            $rootScope.cartCount = persistentOLXFactory.cartContent.length;
            var length = persistentOLXFactory.cartContent.length;
            $scope.totalPrice = 0;
            $scope.totalItemCount = persistentOLXFactory.cartContent.length;
            persistentOLXFactory.totalCartItemCount = persistentOLXFactory.cartContent.length;
            for (var j = 0; j < length; j++) {
                $scope.totalPrice += persistentOLXFactory.cartContent[j].price;
            }
            persistentOLXFactory.totalPrice = $scope.totalPrice;
            $scope.cartItems = persistentOLXFactory.cartContent;
            if ($scope.cartItems.length === 0) {
                $scope.totalPrice = 0;
                $scope.totalItemCount = 0;
            }
        }
        $scope.removeItemFromCart = function (rowIndex) {
            $scope.cartItems[rowIndex].id
            for (var i = 0; i < persistentOLXFactory.cartContent.length; i++) {
                if ($scope.cartItems[rowIndex].id === persistentOLXFactory.cartContent[i]) {
                    persistentOLXFactory.cartContent.splice(i, 1)
                }
            }
            $scope.cartItems.splice(rowIndex, 1);
            renderCartTable();
        };
    });